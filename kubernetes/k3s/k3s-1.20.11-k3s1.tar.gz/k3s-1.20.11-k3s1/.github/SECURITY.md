# Security

Rancher Labs supports responsible disclosure and endeavors to resolve security
issues in a reasonable timeframe. To report a security vulnerability, email
[security@rancher.com](mailto:security@rancher.com)
