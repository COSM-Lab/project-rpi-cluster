package main

import "github.com/rancher/k3s/pkg/ctr"

func main() {
	ctr.Main()
}
