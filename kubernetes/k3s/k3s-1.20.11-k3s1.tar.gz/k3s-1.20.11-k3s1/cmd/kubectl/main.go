package main

import "github.com/rancher/k3s/pkg/kubectl"

func main() {
	kubectl.Main()
}
