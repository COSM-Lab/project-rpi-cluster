# Build a Kubernetes cluster using k3s via Ansible

The ansible playbook was moved to https://github.com/rancher/k3s-ansible
