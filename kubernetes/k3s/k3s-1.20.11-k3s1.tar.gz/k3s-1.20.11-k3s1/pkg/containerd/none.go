// +build !ctrd

package containerd

func Main() {
}
