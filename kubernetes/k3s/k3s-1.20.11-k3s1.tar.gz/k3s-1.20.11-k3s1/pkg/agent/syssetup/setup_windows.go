package syssetup

func Configure() {}
