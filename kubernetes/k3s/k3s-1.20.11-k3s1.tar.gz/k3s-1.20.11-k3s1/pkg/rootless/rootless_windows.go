package rootless

func Rootless(stateDir string) error {
	panic("Rootless not supported on windows")
}
