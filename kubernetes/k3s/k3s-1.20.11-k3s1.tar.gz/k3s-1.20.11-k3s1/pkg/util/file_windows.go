package util

import (
	"os"
)

func SetFileModeForPath(name string, mode os.FileMode) error {
	return nil
}

func SetFileModeForFile(file *os.File, mode os.FileMode) error {
	return nil
}
