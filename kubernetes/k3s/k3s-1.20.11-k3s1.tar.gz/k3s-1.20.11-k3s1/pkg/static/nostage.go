// +build no_stage

package static

func Stage(dataDir string) error {
	return nil
}
